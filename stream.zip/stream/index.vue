<template>
  <div>
    <a-page-header title="直播管理" :ghost="false"></a-page-header>
    <StreamTable></StreamTable>
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  import StreamTable from './components/StreamTable.vue'

  export default defineComponent({
    name: 'Stream',
    components: { StreamTable },
  });
</script>
