<template>
  <div>
    <BasicTable @register="registerTable" :actionColumn="actionColumn">
      <template #toolbar>
        <a-button type="primary" @click="addNewStream">新增</a-button>
      </template>
    </BasicTable>
    <StreamFormModal @register="registerModal" @success="onSaveSuccess" />
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  import { BasicTable, useTable } from '/@/components/Table';
  import { useModal } from '/@/components/Modal';
  import StreamFormModal from './StreamFormModal.vue';
  import { getBasicColumns, getSearchConfig, createActionColumn } from './_helper'
  import { getStreamListApi, deleteStreamApi } from '/@/api/media/stream'
  import { Stream } from '/@/api/media/streamModel';
  import { ResultEnum } from '/@/enums/httpEnum';

  export default defineComponent({
    name: 'StreamTable',
    components: { BasicTable, StreamFormModal },
    setup() {
      const [registerModal, { openModal }] = useModal();

      const [
        registerTable,
        {
          reload,
        }
      ] = useTable({
        // canResize: false,
        api: getStreamListApi,
        columns: getBasicColumns(),
        rowKey: 'id',
        useSearchForm: true,
        formConfig: getSearchConfig(),
        showTableSetting: true,
      });

      // 删除
      async function handleRemove(record: Stream) {
        const res = await deleteStreamApi(record);
        if (res.code === ResultEnum.SUCCESS) {
          reload();
        }
      }

      // // 预览
      // function handlePreview(record: Stream) {
      //   console.log('预览', record.title);
      // }

      // 编辑
      function handleEdit(record: Stream) {
        openModal(true, {id: record.id});
      }

      function addNewStream() {
        openModal(true, {id: -1});
      }

      function onSaveSuccess() {
        reload();
      }

      return {
        addNewStream,
        registerTable,
        registerModal,
        onSaveSuccess,
        actionColumn: createActionColumn({
          handleRemove, handleEdit
        }),
      };
    },
  });
</script>
