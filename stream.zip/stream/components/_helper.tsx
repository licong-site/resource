import { StreamStatusEnum, StreamTypeEnum } from '/@/api/media/streamModel';
import { ActionItem, BasicColumn, TableAction, FormProps } from '/@/components/Table';
import { FormSchema } from '/@/components/Form';
import { Tag } from 'ant-design-vue';

export function getBasicColumns(): BasicColumn[] {
  return [
    {
      title: 'ID',
      dataIndex: 'id',
      width: 80,
    },
    {
      title: '标题',
      dataIndex: 'title',
      width: 120,
    },
    {
      title: '描述',
      dataIndex: 'description',
      width: 120,
      ellipsis: true,
    },
    {
      dataIndex: 'status',
      title: '状态',
      width: 100,
      customRender: ({ text }) => {
        if (text === StreamStatusEnum.ONLINE) {
          return <Tag color="green">{() => '上线'}</Tag>;
        } else if (text === StreamStatusEnum.OFFLINE) {
          return <Tag color="red">{() => '下线'}</Tag>;
        }

        return text;
      },
    },
    {
      title: '类型',
      dataIndex: 'type', // 1 央视 2 卫视 3 CIBN
      width: 80,
      customRender: ({ text }) => {
        if (text === StreamTypeEnum.CCTV) {
          return '央视';
        } else if (text === StreamTypeEnum.WEISHI) {
          return '卫视';
        } else if (text === StreamTypeEnum.CIBN) {
          return 'CIBN';
        }

        return text;
      },
    },
    {
      title: '播放地址',
      dataIndex: 'url',
    },
    {
      title: '上线时间',
      dataIndex: 'onlineTime',
    },
  ];
}

/**
 * @param {
 *  handleRemove: Function,
 *  handlePreview: Function
 * }
 */
export function createActionColumn(handlerFns: { [key: string]: Function }): BasicColumn {
  return {
    width: 140,
    title: '操作',
    dataIndex: 'action',
    fixed: false,
    customRender: ({ record }) => {
      const actions: ActionItem[] = [
        {
          label: '删除',
          color: 'error',
          popConfirm: {
            title: '确定要执行删除操作吗',
            okText: '确定',
            cancelText: '取消',
            confirm: handlerFns['handleRemove'].bind(null, record),
          },
        },
      ];
      // if (record.url && handlerFns['handlePreview']) {
      //   actions.unshift({
      //     label: '预览',
      //     onClick: handlerFns['handlePreview'].bind(null, record),
      //   });
      // }
      actions.unshift({
        label: '编辑',
        onClick: handlerFns['handleEdit'].bind(null, record),
      });
      return <TableAction actions={actions} />;
    },
  };
}

export function getSearchConfig(): Partial<FormProps> {
  return {
    labelWidth: 80,
    schemas: [
      {
        field: 'id',
        label: '直播ID',
        component: 'Input',
        colProps: {
          xl: 8,
          xxl: 6,
        },
      },
      {
        field: 'title',
        label: '标题',
        component: 'Input',
        colProps: {
          xl: 8,
          xxl: 6,
        },
      },
      {
        field: `status`,
        label: `状态`,
        component: 'Select',
        componentProps: {
          options: [
            {
              label: '下线',
              value: 0,
            },
            {
              label: '上线',
              value: 1,
            },
          ],
        },
        colProps: {
          xl: 8,
          xxl: 6,
        },
      },
    ],
  };
}

export const formSchemas: FormSchema[] = [
  {
    field: 'title',
    component: 'Input',
    label: '标题',
    rules: [
      {
        required: true,
        type: 'string',
      },
    ],
  },
  {
    field: 'description',
    component: 'InputTextArea',
    label: '简介',
    componentProps: {
      placeholder: '请输入直播媒资简介。。。',
      rows: 3,
    },
    required: false,
  },
  {
    field: 'url',
    component: 'Input',
    label: '播放地址',
    rules: [
      {
        required: true,
        type: 'string',
      },
    ],
  },
  {
    field: 'status',
    component: 'RadioGroup',
    label: '上线状态',
    componentProps: {
      options: [
        {
          label: '下线',
          value: 0,
        },
        {
          label: '上线',
          value: 1,
        },
      ],
    },
    rules: [
      {
        required: true,
        type: 'number',
      },
    ],
  },
  {
    field: 'type',
    component: 'Select',
    label: '直播类型',
    rules: [
      {
        required: true,
        type: 'number',
      },
    ],
    componentProps: {
      options: [
        {
          label: '央视',
          value: 1,
          key: '1',
        },
        {
          label: '卫视',
          value: 2,
          key: '2',
        },
        {
          label: 'CIBN',
          value: 3,
          key: '3',
        },
      ],
    },
  },
  {
    field: 'onlineTime',
    component: 'DatePicker',
    label: '上线时间',
  },
];
