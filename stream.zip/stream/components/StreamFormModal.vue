<template>
  <BasicModal v-bind="$attrs" title="直播媒资基础信息" @ok="handleOk" @cancel="handleCancel" @register="registerModal">
    <BasicForm @register="registerForm" />
  </BasicModal>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';
import { BasicModal, useModalInner } from '/@/components/Modal';
import { BasicForm, FormSchema, useForm } from '/@/components/Form';
import { useMessage } from '/@/hooks/web/useMessage';
import { getStreamInfoApi, addStreamApi, updateStreamInfoApi } from '/@/api/media/stream';
import { formSchemas } from './_helper';
import { Stream } from '/@/api/media/streamModel';
import { ResultEnum } from '/@/enums/httpEnum';

export default defineComponent({
  name: 'StreamFormModal',
  components: { BasicModal, BasicForm },
  emits: ['success'], // 不注册 register, 注册后无法获取model传递的数据
  setup(_, { emit }) {

    let streamInfo = {};
    const { createMessage } = useMessage();

    const [registerForm, { validateFields, setFieldsValue, resetFields }] = useForm({
      labelWidth: 120,
      schemas: formSchemas,
      showActionButtonGroup: false,
    });

    const [registerModal, { closeModal, changeLoading }] = useModalInner((data) => {
      console.log('useModalInner 回调')
      if (data.id && data.id !== -1) {
        setFormValues(data.id);
      } else {
        streamInfo = {}
      }
    });

    async function setFormValues (id: number) {
      changeLoading(true);
      streamInfo = await getStreamInfoApi({id: id });
      setFieldsValue(streamInfo);
      changeLoading(false);

      // Form 表单字段赋值
      // 方式 1
      // const modelRef = ref({});
      // modelRef.value = info;
      // model: modelRef

      // 方式 2
      // setFieldsValue(info);

      // 方式 3
      // setProps({
      //   model: info
      // })
    }

    function handleCancel(){
      resetFields();
    }

    async function handleOk(){
      try {
        const formData = (await validateFields()) as Stream;
        Object.assign(streamInfo, formData); // 合并原数据和form表单里的新数据
        const apiFn = streamInfo.id ? updateStreamInfoApi : addStreamApi;

        changeLoading(true);
        const res = await apiFn(streamInfo);
        changeLoading(false);

        if (res.code === ResultEnum.SUCCESS) {
          emit('success');
          closeModal();
          handleCancel();
        }
      } catch (error) {
        return;
      }
    }

    return {
      handleOk,
      handleCancel,
      registerModal,
      registerForm,
    }
  },
});
</script>

<style>

</style>
