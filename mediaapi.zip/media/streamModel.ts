import { BasicPageParams, BasicFetchResult, BasicInfoParams } from '/@/api/model/baseModel';
/**
 * @description: Request list interface parameters
 */
export type StreamListParams = BasicPageParams;

export type StreamInfoParams = BasicInfoParams;

export interface Stream {
  id: number;
  title: string;
  onlineTime: string;
  url: string;
  description: string;
  status: number;
  type: number;
}

/**
 * @description: Request list return value
 */
export type StreamListGetResultModel = BasicFetchResult<Stream>;

export enum StreamStatusEnum {
  ONLINE = 1,
  OFFLINE = 0,
}

export enum StreamTypeEnum { // 1 央视 2 卫视 3 CIBN
  CCTV = 1,
  WEISHI = 2,
  CIBN = 3,
}
