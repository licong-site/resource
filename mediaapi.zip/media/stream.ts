import { defHttp } from '/@/utils/http/axios';
import {
  StreamListParams,
  StreamListGetResultModel,
  StreamInfoParams,
  Stream,
} from './streamModel';

enum Api {
  STREAM_LIST = '/v1/streamlist',
  STREAM_INFO = '/v1/stream',
}

/**
 * @description: Get sample list value
 */
export function getStreamListApi(params: StreamListParams) {
  return defHttp.request<StreamListGetResultModel>({
    url: Api.STREAM_LIST,
    method: 'GET',
    params,
    headers: {
      ignoreCancelToken: true,
    },
  });
}

/**
 * description: 根据直播ID获取直播媒资详情
 */
export function getStreamInfoApi(params: StreamInfoParams) {
  return defHttp.request<Stream>({
    url: Api.STREAM_INFO,
    params,
    method: 'GET',
  });
}

/**
 * description: 更新直播媒资
 */
export function updateStreamInfoApi(params: Stream) {
  return defHttp.request<Stream>(
    {
      url: `${Api.STREAM_INFO}/${params.id}`,
      params,
      method: 'PUT',
    },
    {
      isTransformRequestResult: false,
      idShowTipMessage: true,
    }
  );
}

/**
 * description: 新建直播媒资
 */
export function addStreamApi(params: Stream) {
  return defHttp.request<Stream>(
    {
      url: Api.STREAM_INFO,
      params,
      method: 'POST',
    },
    {
      isTransformRequestResult: false,
      idShowTipMessage: true,
    }
  );
}

/**
 * description: 删除直播媒资
 */
export function deleteStreamApi(params: Stream) {
  return defHttp.request<Stream>(
    {
      url: `${Api.STREAM_INFO}/${params.id}`,
      method: 'DELETE',
    },
    {
      isTransformRequestResult: false,
      idShowTipMessage: true,
    }
  );
}
